export default [
    {
        "post_title":"Sun on Lake",
        "post_date":"2020-01-01",
        "photo_url":"https://images.pexels.com/photos/2613946/pexels-photo-2613946.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",


    },
    {
        "post_title":"Sun on Lake",
        "post_date":"2020-01-01",
        "photo_url":"https://images.pexels.com/photos/2613946/pexels-photo-2613946.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",


    },
    {
        "post_title":"Sun on Lake",
        "post_date":"2020-01-01",
        "photo_url":"https://images.pexels.com/photos/2613946/pexels-photo-2613946.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",


    },
    {
        "post_title":"Sun on Lake",
        "post_date":"2020-01-01",
        "photo_url":"https://images.pexels.com/photos/2613946/pexels-photo-2613946.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",


    },
    {
        "post_title":"Sun on Lake",
        "post_date":"2020-01-01",
        "photo_url":"https://images.pexels.com/photos/2613946/pexels-photo-2613946.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",


    }

]