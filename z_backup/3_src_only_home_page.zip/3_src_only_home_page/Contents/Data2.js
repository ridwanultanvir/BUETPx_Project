export default [
    {
    id: "2000",
    post_title: "Sunny Day",
    post_date: "2010-08-02T21:27:44+0000",
    photo_url: "1.jpg",
    owner: "1000",
    category: "landscape",
    place: "Boston, MA",
    tags: "sun"
 },
 {
    id: "2001",
    post_title: "Sunny Day",
    post_date: "2010-08-02T21:27:44+0000",
    photo_url: "1.jpg",
    owner: "2001",
    category: "landscape",
    place: "Boston, MA",
    tags: "sun"
 },
 {
    id: "2001",
    post_title: "Sunny Day",
    post_date: "2010-08-02T21:27:44+0000",
    photo_url: "1.jpg",
    owner: "2001",
    category: "landscape",
    place: "Boston, MA",
    tags: "sun"
 },
 {
    id: "2001",
    post_title: "Sunny Day",
    post_date: "2010-08-02T21:27:44+0000",
    photo_url: "1.jpg",
    owner: "2001",
    category: "landscape",
    place: "Boston, MA",
    tags: "sun"
 },
 {
    id: "2001",
    post_title: "Sunny Day",
    post_date: "2010-08-02T21:27:44+0000",
    photo_url: "1.jpg",
    owner: "2001",
    category: "landscape",
    place: "Boston, MA",
    tags: "sun"
 },
 {
    id: "2001",
    post_title: "Sunny Day",
    post_date: "2010-08-02T21:27:44+0000",
    photo_url: "1.jpg",
    owner: "2001",
    category: "landscape",
    place: "Boston, MA",
    tags: "sun"
 }
 
];