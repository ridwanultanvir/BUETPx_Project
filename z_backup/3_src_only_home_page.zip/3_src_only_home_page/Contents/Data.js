export default [
    {
    id: 2000,
    post_title: "Sunny Day",
    post_date: "2010-08-02T21:27:44+0000",
    photo_url: "1.jpg",
    owner: 1000,
    category: "landscape",
    place: "Boston, MA",
    tags: ["sun", "cloud", "sky"]
 },
 {
    id: 2001,
    post_title: "Sunny Day",
    post_date: "2010-08-02T21:27:44+0000",
    photo_url: "https://www.google.com/url?sa=i&source=images&cd=&cad=rja&uact=8&ved=2ahUKEwj_8-_x9_qjAhVFJqYKHX_sD-AQjRx6BAgBEAU&url=https%3A%2F%2Fwww.pexels.com%2Fsearch%2Farafat%2F&psig=AOvVaw0_X_X_X_X_X_X_X&ust=1560984100824000&imgdurl=https%3A%2F%2Fimages.pexels.com%2Fphotos%2F853991%2Fpexels-photo-853991.jpeg",
    owner: 1000,
    category: "landscape",
    place: "Boston, MA",
    tags: ["sun", "cloud", "sky"]
 },
 {
    id: 2002,
    post_title: "Sunny Day",
    post_date: "2010-08-02T21:27:44+0000",
    photo_url: "https://www.google.com/url?sa=i&source=images&cd=&cad=rja&uact=8&ved=2ahUKEwj_8-_x9_qjAhVFJqYKHX_sD-AQjRx6BAgBEAU&url=https%3A%2F%2Fwww.pexels.com%2Fsearch%2Farafat%2F&psig=AOvVaw0_X_X_X_X_X_X_X&ust=1560984100824000&imgdurl=https%3A%2F%2Fimages.pexels.com%2Fphotos%2F853991%2Fpexels-photo-853991.jpeg",
    owner: 1000,
    category: "landscape",
    place: "Boston, MA",
    tags: ["sun", "cloud", "sky"]
 },
 {
    id: 2003,
    post_title: "Sunny Day",
    post_date: "2010-08-02T21:27:44+0000",
    photo_url: "https://www.google.com/url?sa=i&source=images&cd=&cad=rja&uact=8&ved=2ahUKEwj_8-_x9_qjAhVFJqYKHX_sD-AQjRx6BAgBEAU&url=https%3A%2F%2Fwww.pexels.com%2Fsearch%2Farafat%2F&psig=AOvVaw0_X_X_X_X_X_X_X&ust=1560984100824000&imgdurl=https%3A%2F%2Fimages.pexels.com%2Fphotos%2F853991%2Fpexels-photo-853991.jpeg",
    owner: 1001,
    category: "landscape",
    place: "Boston, MA",
    tags: ["sun", "cloud", "sky"]
 },
 {
    id: 2004,
    post_title: "Sunny Day",
    post_date: "2010-08-02T21:27:44+0000",
    photo_url: "https://www.google.com/url?sa=i&source=images&cd=&cad=rja&uact=8&ved=2ahUKEwj_8-_x9_qjAhVFJqYKHX_sD-AQjRx6BAgBEAU&url=https%3A%2F%2Fwww.pexels.com%2Fsearch%2Farafat%2F&psig=AOvVaw0_X_X_X_X_X_X_X&ust=1560984100824000&imgdurl=https%3A%2F%2Fimages.pexels.com%2Fphotos%2F853991%2Fpexels-photo-853991.jpeg",
    owner: 1002,
    category: "landscape",
    place: "Boston, MA",
    tags: ["sun", "cloud", "sky"]
 },
 {
    id: 2005,
    post_title: "Sunny Day",
    post_date: "2010-08-02T21:27:44+0000",
    photo_url: "https://www.google.com/url?sa=i&source=images&cd=&cad=rja&uact=8&ved=2ahUKEwj_8-_x9_qjAhVFJqYKHX_sD-AQjRx6BAgBEAU&url=https%3A%2F%2Fwww.pexels.com%2Fsearch%2Farafat%2F&psig=AOvVaw0_X_X_X_X_X_X_X&ust=1560984100824000&imgdurl=https%3A%2F%2Fimages.pexels.com%2Fphotos%2F853991%2Fpexels-photo-853991.jpeg",
    owner: 1004,
    category: "landscape",
    place: "Boston, MA",
    tags: ["sun", "cloud", "sky"]
 }
 
];