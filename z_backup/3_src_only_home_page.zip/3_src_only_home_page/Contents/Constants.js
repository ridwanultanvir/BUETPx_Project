export default [
  {
  id: 2000,
  post_title: "Sunny Day",
  post_date: "2010-08-02T21:27:44+0000",
  photo_url: "https://media.gettyimages.com/photos/wild-meadow-on-summers-day-picture-id1156729138?s=2048x2048",
  owner: 1000,
  category: "landscape",
  place: "Boston, MA",
  tags: ["sun", "cloud", "sky"]
},
{
  id: 2001,
  post_title: "Sunny Day",
  post_date: "2010-08-02T21:27:44+0000",
  photo_url: "https://media.gettyimages.com/photos/straight-empty-road-sweden-picture-id849569686?k=20&m=849569686&s=612x612&w=0&h=mUGs8ql2hDWsrCUYXmSdRObmOqV4Md-P07J83lvMSY4=",
  owner: 1000,
  category: "landscape",
  place: "Boston, MA",
  tags: ["sun", "cloud", "sky"]
},
{
  id: 2002,
  post_title: "Sunny Day",
  post_date: "2010-08-02T21:27:44+0000",
  photo_url: "https://media.gettyimages.com/vectors/sun-in-noon-vector-id943609908?k=20&m=943609908&s=612x612&w=0&h=Zz9CYCugykhT9MsU1zK7TkQSnOLxNyXCiW8XagSsT4s=",
  owner: 1000,
  category: "landscape",
  place: "Boston, MA",
  tags: ["sun", "cloud", "sky"]
},
{
  id: 2003,
  post_title: "Sunny Day",
  post_date: "2010-08-02T21:27:44+0000",
  photo_url: "https://media.gettyimages.com/photos/scenic-view-of-trees-on-field-against-clear-sky-picture-id1169513631?k=20&m=1169513631&s=612x612&w=0&h=W4ifz58E_53heIg1NgYeuAu6VSNmn4O0wXdHvclDstA=",
  owner: 1001,
  category: "landscape",
  place: "Boston, MA",
  tags: ["sun", "cloud", "sky"]
},
{
  id: 2004,
  post_title: "Sunny Day",
  post_date: "2010-08-02T21:27:44+0000",
  photo_url: "https://media.gettyimages.com/vectors/blue-sky-and-clouds-seamless-vector-background-vector-id1163292935?k=20&m=1163292935&s=612x612&w=0&h=UkJc7uklb677HRh_Mn-5mrFM1cy4u8xJUxiYl4540eQ=",
  owner: 1002,
  category: "landscape",
  place: "Boston, MA",
  tags: ["sun", "cloud", "sky"]
},
{
  id: 2005,
  post_title: "Sunny Day",
  post_date: "2010-08-02T21:27:44+0000",
  photo_url: "https://media.gettyimages.com/photos/central-business-district-of-sydney-at-daytime-picture-id973115274?k=20&m=973115274&s=612x612&w=0&h=X1ceWUm3p-TjYpz76w8HGeq9Azqwk6cgwKOLJODjFHQ=",
  owner: 1004,
  category: "landscape",
  place: "Boston, MA",
  tags: ["sun", "cloud", "sky"]
}

];