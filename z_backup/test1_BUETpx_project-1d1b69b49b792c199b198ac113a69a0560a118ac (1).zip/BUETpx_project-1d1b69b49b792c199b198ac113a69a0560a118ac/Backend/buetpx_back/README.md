##

1. CategorySerializer Fix kora
2. TagsSerializer wrong ?
3. SinglePostSerializer
4. CommentSerializer2

##
Caution: settings.py file password: 1234 or 123 

##

new api create: 

extra_kwargs eta ki? 
# tags er moto comment korbo 




##


```
F:\L4T1_code\CSE408_project\dj_env1\Scripts\activate

react-time-format
```

##
Category kothar foreign key?

Post er ;

So Post theke CategorySerializer() call kora jay

Category class e kintu kono foreign key nei