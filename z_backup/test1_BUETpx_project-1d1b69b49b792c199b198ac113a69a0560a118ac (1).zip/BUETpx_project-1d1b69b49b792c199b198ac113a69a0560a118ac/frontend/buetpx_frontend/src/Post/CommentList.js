export default [
{"id": 1, "comment_txt": "Good Pic", "comment_date": "2020-10-01T18:00:00Z", "post": 1, "user": 1}, 
{"id": 3, "comment_txt": "Three Stooges", "comment_date": "2020-10-01T18:00:00Z", "post": 1, "user": 2},
 {"id": 4, "comment_txt": "Stylish Cloth", "comment_date": "2020-10-01T18:00:00Z", "post": 1, "user": 2}
]; 