##

Structured Way: 

Post: 
1. Post.js
2. 

##

Content =common jinish = static jinishpati


##


```
F:\L4T1_code\CSE408_project\dj_env1\Scripts\activate

react-time-format
```

##