
##
buetpx_frontend ==> react 

* a new page added
![](img/Screenshot%20(325).png)

##

[mock ui youtube](https://www.youtube.com/watch?v=tKzSnjWPtEw&t=1733s&ab_channel=AnthonySistilli)
