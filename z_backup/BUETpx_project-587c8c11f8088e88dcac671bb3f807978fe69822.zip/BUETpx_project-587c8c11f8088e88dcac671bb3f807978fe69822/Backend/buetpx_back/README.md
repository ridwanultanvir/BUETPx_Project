##

Structured Way: 

Post: 
1. Post.js
2. 

##

Content =common jinish = static jinishpati
##

##

Questions: 

1. Routing Path 
2. Api call where

1. amadr controller class gula basically django views.py  e implemented 
class diagram er controller gula 
2.  class diagram er view mane amadr React er functions gula


##
@Tanvir

```
F:\L4T1_code\CSE408_project\dj_env1\Scripts\activate

react-time-format
```

##

sorting; multiple category 

##
Tags.js : only Tags show kore 


## 

Button Click kore another page e: 

https://bobbyhadz.com/blog/react-onclick-redirect 


## 

Post e : Tags ManyToMany Filter ; so 
https://stackoverflow.com/questions/2218327/django-manytomany-filter

posts = Post.objects.filter(tags__in = id)  simple