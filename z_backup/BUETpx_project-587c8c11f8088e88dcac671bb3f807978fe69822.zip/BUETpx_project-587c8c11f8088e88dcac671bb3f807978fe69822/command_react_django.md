##

```
npx create-react-app react_buetpx
cd react_buetpx
npm start
npm install react-router-dom@6
```

* if react er bhitorer git folder delete 
```
rmdir /S .git
```

1. App.js 
2. next assets/img folder create 
3. components/Populartags.js create (eta website theke neya hoise: kajer easy te)
##

```
npx create-react-app react_buetpx
cd react_buetpx
npm start
npm install react-router-dom@6
```

* if react er bhitorer git folder delete 
```
rmdir /S .git
```

1. App.js 
2. next assets/img folder create 
3. components/Populartags.js create (eta website theke neya hoise: kajer easy te)

##
@Tanvir: 


```
F:\L4T1_code\CSE408_project\dj_env1\Scripts\activate

```
(dj_env1) F:\L4T1_code\CSE408_project\BUETpx_project>cd Backend
python manage.py runserver

##
open cmd: 
```
conda create --name js_env1
conda activate js_env1
conda deactivate

conda init powershell
```
* ekhane npm er package gula rakhsi 

* some weird reason : ager package.json file delete kore disilam
```
npm install @material-ui/core
```
* but eta error dey; 
Fix: 
```
npm install --legacy-peer-deps @material-ui/core
```


```
npm install --legacy-peer-deps @material-ui/icons
npm install --legacy-peer-deps @material-ui/styles
```


##

```
npm install --legacy-peer-deps 
npm install --legacy-peer-deps react-time-format

npm install --legacy-peer-deps semantic-ui-react semantic-ui-css

npm install --legacy-peer-deps react-comments-section
```
